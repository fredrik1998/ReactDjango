import{s as a,y as n,j as r,R as e,C as s}from"./index-5a45e034.js";const t=a(n)`
background-color: #1a1a1a;
color: #fff;
border: 1px transparent;
border-radius: 12px;
`;function d({children:o}){return r(t,{children:r(e,{className:"justify-content-md-center",children:r(s,{xs:12,md:7,children:o})})})}export{d as F};
