import{j as e,X as t}from"./index-c06f9d58.js";function o({variant:r,children:s}){return e(t,{variant:r,children:s})}export{o as M};
