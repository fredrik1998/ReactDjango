import{j as e,X as t}from"./index-03493f3e.js";function o({variant:r,children:s}){return e(t,{variant:r,children:s})}export{o as M};
